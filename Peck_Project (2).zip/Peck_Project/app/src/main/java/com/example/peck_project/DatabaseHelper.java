package com.example.peck_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Logins.db";
    private static final int DATABASE_VERSION = 4; // Version 4 handles users, inventory, and audits using Supabase

    // Table: Users
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USER_EMAIL = "email_address";
    private static final String COL_USER_PASSWORD_HASH = "password_hash";
    private static final String COL_USER_CREATED_AT = "created_at";
    private static final String COL_USER_UPDATED_AT = "updated_at";

    // Table: Inventory
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_INVENTORY_ITEM_ID = "id";
    private static final String COL_INVENTORY_USER_ID = "user_id";
    private static final String COL_INVENTORY_SKU = "sku";
    private static final String COL_INVENTORY_ITEM_NAME = "item_name";
    private static final String COL_INVENTORY_ITEM_DESC = "item_description";
    private static final String COL_INVENTORY_ITEM_QTY = "item_quantity";
    private static final String COL_INVENTORY_CREATED_AT = "created_at";
    private static final String COL_INVENTORY_UPDATED_AT = "updated_at";
    private static final String COL_INVENTORY_COST_PRICE = "cost_price";
    private static final String COL_INVENTORY_RETAIL_PRICE = "retail_price";
    private static final String COL_INVENTORY_REORDER_POINT = "reorder_point";
    private static final String COL_INVENTORY_ITEM_IMAGE = "item_image";

    //Table: Locations
    private static final String TABLE_LOCATIONS = "locations";
    private static final String COL_LOCATIONS_ID = "id";
    private static final String COL_LOCATIONS_USER = "user_id";
    private static final String COL_LOCATIONS_NAME = "location_name";
    private static final String COL_LOCATIONS_SUB_LOCATION = "sub_location";
    private static final String COL_LOCATIONS_CREATED_AT = "created_at";

    //Table Inventory_Locations
    private static final String TABLE_INVENTORY_LOCATIONS = "inventory_locations";
    private static final String COL_INV_LOC_INV_ID = "inv_id";
    private static final String COL_INV_LOC_LOC_ID = "loc_id";
    private static final String COL_INV_LOC_QUANTITY = "quantity";

    //Table: Barcodes
    private static final String TABLE_BARCODES = "barcodes";
    private static final String COL_BARCODES_ID = "barcode_id";
    private static final String COL_BARCODES_INV_ID = "inv_id";
    private static final String COL_BARCODES_VALUE = "barcode_value";
    private static final String COL_BARCODES_TYPE = "barcode_type";

    //Table: Stock Movements
    private static final String TABLE_STOCK_MOVEMENTS = "stock_movements";
    private static final String COL_STOCK_MOVEMENTS_ID = "stock_movement_id";
    private static final String COL_STOCK_MOVEMENTS_USER_ID = "stock_movement_user_id";
    private static final String COL_STOCK_MOVEMENTS_INV_ID = "stock_movement_inv_id";
    private static final String COL_STOCK_MOVEMENTS_LOCATION_ID = "stock_movement_loc_id";
    private static final String COL_STOCK_MOVEMENTS_QUANTITY_CHANGE = "stock_movement_quan_change";
    private static final String COL_STOCK_MOVEMENTS_REASON = "stock_movement_reason";
    private static final String COL_STOCK_MOVEMENTS_CREATED_AT = "stock_movement_created_at";

    //Table: Audits
    private static final String TABLE_AUDITS = "audits";
    private static final String COL_AUDITS_ID = "audits_id";
    private static final String COL_AUDITS_USER_ID = "audits_user";
    private static final String COL_AUDITS_INV_ID = "audits_inv_id";
    private static final String COL_AUDITS_LOC_ID = "audits_loc_id";
    private static final String COL_AUDITS_EXP_QTY = "audits_expected";
    private static final String COL_AUDITS_ACT_QTY = "audits_actual";
    private static final String COL_AUDITS_STATUS = "audits_status";
    private static final String COL_AUDITS_NOTES = "audits_notes";
    private static final String COL_AUDITS_CREATED_AT = "audits_created";
    private static final String COL_AUDITS_RESOLVED_AT = "audits_resolved_at";
    private static final String COL_AUDITS_DISCREPANCY = "audits_discrepancy";

    // Cache Management Meta-Columns
    private static final String COL_IS_DIRTY = "is_dirty";         // 1 if updated offline, 0 if synced
    private static final String COL_LAST_UPDATED = "last_updated";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create Users Table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " TEXT PRIMARY KEY, " + // Supabase auth UUIDs are strings
                COL_USER_EMAIL + " TEXT UNIQUE, " +
                COL_USER_PASSWORD_HASH + " TEXT, " +
                COL_USER_CREATED_AT + " TEXT, " +
                COL_USER_UPDATED_AT + " TEXT)";
        db.execSQL(createUsersTable);

        //Create Inventory Table
        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_INVENTORY_ITEM_ID + " TEXT PRIMARY KEY, " + // UUID from Supabase
                COL_INVENTORY_USER_ID + " TEXT, " +
                COL_INVENTORY_SKU + " TEXT UNIQUE, " +
                COL_INVENTORY_ITEM_NAME + " TEXT, " +
                COL_INVENTORY_ITEM_DESC + " TEXT, " +
                COL_INVENTORY_ITEM_QTY + " INTEGER, " + // int8 maps cleanly to SQLite INTEGER
                COL_INVENTORY_COST_PRICE + " REAL, " +    // Numeric/decimal fields use REAL
                COL_INVENTORY_RETAIL_PRICE + " REAL, " +  // Numeric/decimal fields use REAL
                COL_INVENTORY_REORDER_POINT + " INTEGER, " +
                COL_INVENTORY_ITEM_IMAGE + " BLOB, " +
                COL_INVENTORY_CREATED_AT + " TEXT, " +
                COL_INVENTORY_UPDATED_AT + " TEXT, " +
                "is_dirty INTEGER DEFAULT 0)"; // Cache synchronization flag
        db.execSQL(createInventoryTable);

        //Create Locations Table
        String createLocationsTable = "CREATE TABLE " + TABLE_LOCATIONS + " (" +
                COL_LOCATIONS_ID + " TEXT PRIMARY KEY, " + // UUID from Supabase
                COL_LOCATIONS_USER + " TEXT, " +
                COL_LOCATIONS_NAME + " TEXT, " +
                COL_LOCATIONS_SUB_LOCATION + " TEXT, " +
                COL_LOCATIONS_CREATED_AT + " TEXT, " +
                "is_dirty INTEGER DEFAULT 0)"; // Cache synchronization flag
        db.execSQL(createLocationsTable);

        //Create Inventory_Locations Table (Your Composite Primary Key Table)
        String createInventoryLocationsTable = "CREATE TABLE " + TABLE_INVENTORY_LOCATIONS + " (" +
                COL_INV_LOC_INV_ID + " TEXT NOT NULL, " +
                COL_INV_LOC_LOC_ID + " TEXT NOT NULL, " +
                COL_INV_LOC_QUANTITY + " INTEGER NOT NULL, " +
                "is_dirty INTEGER DEFAULT 0, " + // Cache synchronization flag
                "PRIMARY KEY (" + COL_INV_LOC_INV_ID + ", " + COL_INV_LOC_LOC_ID + "))";
        db.execSQL(createInventoryLocationsTable);

        // Create Barcodes Table (Fixed target mapping name string assignment)
        String createBarcodesTable = "CREATE TABLE barcodes (" +
                COL_BARCODES_ID + " TEXT PRIMARY KEY, " + // UUID from Supabase
                COL_BARCODES_INV_ID + " TEXT, " +
                COL_BARCODES_VALUE + " TEXT UNIQUE, " +
                COL_BARCODES_TYPE + " TEXT, " +
                "is_dirty INTEGER DEFAULT 0)"; // Cache synchronization flag
        db.execSQL(createBarcodesTable);

        //Create Stock Movements Table
        String createStockMovementsTable = "CREATE TABLE " + TABLE_STOCK_MOVEMENTS + " (" +
                COL_STOCK_MOVEMENTS_ID + " TEXT PRIMARY KEY, " + // UUID from Supabase
                COL_STOCK_MOVEMENTS_USER_ID + " TEXT, " +
                COL_STOCK_MOVEMENTS_INV_ID + " TEXT, " +
                COL_STOCK_MOVEMENTS_LOCATION_ID + " TEXT, " +
                COL_STOCK_MOVEMENTS_QUANTITY_CHANGE + " INTEGER, " +
                COL_STOCK_MOVEMENTS_REASON + " TEXT, " +
                COL_STOCK_MOVEMENTS_CREATED_AT + " TEXT, " +
                "is_dirty INTEGER DEFAULT 0)"; // Cache synchronization flag
        db.execSQL(createStockMovementsTable);

        //Create Audits Table
        String createAuditsTable = "CREATE TABLE " + TABLE_AUDITS + " (" +
                COL_AUDITS_ID + " TEXT PRIMARY KEY, " + // UUID from Supabase
                COL_AUDITS_USER_ID + " TEXT, " +
                COL_AUDITS_INV_ID + " TEXT, " +
                COL_AUDITS_LOC_ID + " TEXT, " +
                COL_AUDITS_EXP_QTY + " INTEGER, " +
                COL_AUDITS_ACT_QTY + " INTEGER, " +
                COL_AUDITS_STATUS + " TEXT, " +
                COL_AUDITS_NOTES + " TEXT, " +
                COL_AUDITS_CREATED_AT + " TEXT, " +
                COL_AUDITS_RESOLVED_AT + " TEXT, " +
                COL_AUDITS_DISCREPANCY + " INTEGER, " + // Auto-calculated int8 math field from server
                "is_dirty INTEGER DEFAULT 0)"; // Cache synchronization flag
        db.execSQL(createAuditsTable);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY_LOCATIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BARCODES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STOCK_MOVEMENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_AUDITS);
        onCreate(db);
    }

    //Grabs any locally modified inventory rows that need to be pushed up to Supabase.
    public Cursor getUnsyncedInventory() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, "is_dirty = 1", null, null, null, null);
    }

    //Clears the dirty flag once Retrofit successfully updates the cloud.
    public void markInventoryAsSynced(String itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("is_dirty", 0);
        db.update(TABLE_INVENTORY, values, COL_INVENTORY_ITEM_ID + " = ?", new String[]{itemId});
    }

    // USER OPERATIONS
    public boolean registerUser(String uuid, String email, String passwordHash) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USER_ID, uuid); // Save the Supabase Auth UUID
        contentValues.put(COL_USER_EMAIL, email);
        contentValues.put(COL_USER_PASSWORD_HASH, passwordHash);
        contentValues.put(COL_USER_CREATED_AT, String.valueOf(System.currentTimeMillis()));
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public boolean checkUserCredentials(String email, String passwordHash) {
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COL_USER_EMAIL + " = ? AND " + COL_USER_PASSWORD_HASH + " = ?";
        String[] selectionArgs = {email, passwordHash};
        Cursor cursor = db.query(TABLE_USERS, null, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    // INVENTORY OPERATIONS
    public boolean addItem(String itemId, String userId, String sku, String name, String description, int quantity, double cost, double retail, int reorderPoint, byte[] imageBytes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_INVENTORY_ITEM_ID, itemId);
        contentValues.put(COL_INVENTORY_USER_ID, userId);
        contentValues.put(COL_INVENTORY_SKU, sku);
        contentValues.put(COL_INVENTORY_ITEM_NAME, name);
        contentValues.put(COL_INVENTORY_ITEM_DESC, description);
        contentValues.put(COL_INVENTORY_ITEM_QTY, quantity);
        contentValues.put(COL_INVENTORY_COST_PRICE, cost);
        contentValues.put(COL_INVENTORY_RETAIL_PRICE, retail);
        contentValues.put(COL_INVENTORY_REORDER_POINT, reorderPoint);
        contentValues.put(COL_INVENTORY_ITEM_IMAGE, imageBytes);
        contentValues.put("is_dirty", 1); // Marked dirty so it syncs up to the cloud!

        long result = db.insert(TABLE_INVENTORY, null, contentValues);
        return result != -1;
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_INVENTORY, null, null, null, null, null, null);
    }
    public boolean updateItemQuantity(String itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_INVENTORY_ITEM_QTY, newQuantity);
        contentValues.put("is_dirty", 1); // Local change requires a cloud sync

        int rowsAffected = db.update(TABLE_INVENTORY, contentValues, COL_INVENTORY_ITEM_ID + " = ?", new String[]{itemId});
        return rowsAffected > 0;
    }

    public boolean deleteItem(String itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_INVENTORY, COL_INVENTORY_ITEM_ID + " = ?", new String[]{itemId});
        return rowsDeleted > 0;
    }

    // AUDIT OPERATIONS
    public boolean logDiscrepancy(String auditId, String userId, String invId, String locId, int expected, int actual, String status, String notes) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_AUDITS_ID, auditId);
        contentValues.put(COL_AUDITS_USER_ID, userId);
        contentValues.put(COL_AUDITS_INV_ID, invId);
        contentValues.put(COL_AUDITS_LOC_ID, locId);
        contentValues.put(COL_AUDITS_EXP_QTY, expected);
        contentValues.put(COL_AUDITS_ACT_QTY, actual);
        contentValues.put(COL_AUDITS_STATUS, status);
        contentValues.put(COL_AUDITS_NOTES, notes);
        contentValues.put(COL_AUDITS_CREATED_AT, String.valueOf(System.currentTimeMillis()));
        // Note: COL_AUDITS_DISCREPANCY will be calculated automatically by Supabase math columns on fetch
        contentValues.put("is_dirty", 1);

        long result = db.insert(TABLE_AUDITS, null, contentValues);
        return result != -1;
    }

    public int getLowStockCount(int threshold) {
        SQLiteDatabase db = this.getReadableDatabase();
        // Updated to use your new table and column name mappings
        String query = "SELECT COUNT(*) FROM " + TABLE_INVENTORY + " WHERE " + COL_INVENTORY_ITEM_QTY + " < ?";
        String[] selectionArgs = { String.valueOf(threshold) };

        Cursor cursor = db.rawQuery(query, selectionArgs);
        int count = 0;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
            cursor.close();
        }
        return count;
    }

}
